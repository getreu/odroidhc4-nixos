﻿---
title:        Emby Server for Linux - Emby
subtitle:     url
author:       Getreu
date:         2025-01-09
lang:         de-DE
---

[Emby Server for Linux - Emby](https://emby.media/linux-server.html)


> **Ubuntu Arm64 (aarch64)**
> 
> 1.  Download [emby-server-deb\_4.8.10.0\_arm64.deb](https://github.com/MediaBrowser/Emby.Releases/releases/download/4.8.10.0/emby-server-deb_4.8.10.0_arm64.deb)
> 2.  `dpkg -i emby-server-deb_4.8.10.0_arm64.deb`
> 3.  Open a web browser to <https://localhost:8096>
> 4.  Check `systemctl status emby-server.service`
