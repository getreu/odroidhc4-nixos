$env.config.show_banner = false
$env.config.buffer_editor = "hx"



### Jens
alias lsync = sudo /home/getreu-dev/projects/lsync bucketnas2.lan
# alias lsync = sudo /home/getreu-dev/projects/lsync 192.168.1.120
alias adj = sudo /home/getreu-dev/projects/adjust-home_doc-permissions
alias ulbn = /home/getreu-dev/projects/bucketnas-unlock
alias lkbn = /home/getreu-dev/projects/bucketnas-lock
alias von = sudo wgnord c lv
alias voff = sudo wgnord d
alias sshbn = ssh -l root bucketnas2.lan
alias rsbn = /home/getreu-dev/projects/bucketnas-restart-media-server
 
